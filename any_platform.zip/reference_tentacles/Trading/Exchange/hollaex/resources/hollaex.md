Hollaex is a basic SpotExchange adaptation for Hollaex exchange. 

Change the api url to connect to a specific hollaex exchange
