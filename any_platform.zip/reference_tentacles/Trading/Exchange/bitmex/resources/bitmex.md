Bitmex is a basic FutureExchange adaptation for Bitmex exchange. 
