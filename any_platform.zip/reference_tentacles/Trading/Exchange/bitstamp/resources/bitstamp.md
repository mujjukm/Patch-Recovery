Bitstamp is a basic SpotExchange adaptation for Bitstamp exchange. 
