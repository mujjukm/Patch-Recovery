FTX is a basic SpotExchange adaptation for FTX exchange. 
