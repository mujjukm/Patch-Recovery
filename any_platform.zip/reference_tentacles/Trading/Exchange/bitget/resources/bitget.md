Bitget is a SpotExchange adaptation for Bitget exchange using the REST API. 
