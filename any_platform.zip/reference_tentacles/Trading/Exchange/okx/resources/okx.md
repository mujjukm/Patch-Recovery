Okx is a basic SpotExchange adaptation for OKX exchange. 
