HuobiPro is a basic SpotExchange adaptation for HuobiPro exchange. 
