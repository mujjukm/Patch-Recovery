WavesExchange is a basic SpotExchange adaptation for WavesExchange exchange. 
