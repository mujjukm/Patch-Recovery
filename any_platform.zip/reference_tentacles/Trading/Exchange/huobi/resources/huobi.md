Huobi is a basic SpotExchange adaptation for Huobi exchange. 
