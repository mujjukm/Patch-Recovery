Hitbtc is a basic SpotExchange adaptation for Hitbtc exchange. 
