Okcoin is a basic SpotExchange adaptation for Okcoin exchange. 
