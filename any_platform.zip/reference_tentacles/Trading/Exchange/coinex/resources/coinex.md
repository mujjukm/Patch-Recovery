coinex is a basic SpotExchange adaptation for coinex exchange. 
