Bybit is a basic SpotExchange adaptation for Bybit exchange.
