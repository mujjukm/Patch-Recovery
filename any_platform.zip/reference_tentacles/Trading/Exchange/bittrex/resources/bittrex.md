Bittrex is a basic SpotExchange adaptation for Bittrex exchange. 
