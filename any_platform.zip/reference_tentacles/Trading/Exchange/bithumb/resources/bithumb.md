Bithumb is a basic SpotExchange adaptation for Bithumb exchange. 
