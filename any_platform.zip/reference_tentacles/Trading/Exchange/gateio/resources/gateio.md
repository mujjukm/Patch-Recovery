GateIO is a basic SpotExchange adaptation for GateIO exchange. 
