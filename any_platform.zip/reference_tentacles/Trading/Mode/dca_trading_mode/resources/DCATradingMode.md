Dollar cost averaging (DCA) is a trading mode that can help you lower the amount you pay for investments and minimize risk. Instead of purchasing investments at a single price point, with dollar cost averaging you buy in smaller amounts at regular intervals, regardless of price. Over the long term, dollar cost averaging can help lower your investment costs and boost your returns.

**When using default configuration**, DCA Trading mode will buy 50$ (or unit of reference market) each week.

DCA Trading mode creates buying limit order at pair current price - 0.1%. 
